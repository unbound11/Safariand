package com.example.glasssafari

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

val Ink = Color(0xFF1C1C1E)

fun Modifier.glass(shape: Shape) = this
    .shadow(18.dp, shape, ambientColor = Color(0x22000000), spotColor = Color(0x44000000))
    .clip(shape)
    .background(Brush.verticalGradient(listOf(Color.White.copy(.86f), Color.White.copy(.58f))))
    .border(1.dp, Brush.verticalGradient(listOf(Color.White, Color.White.copy(.15f))), shape)

fun normalize(input: String): String {
    val t = input.trim()
    if (t.isEmpty()) return ""
    return when {
        t.startsWith("http://") || t.startsWith("https://") -> t
        t.contains(".") && !t.contains(" ") -> "https://$t"
        else -> "https://duckduckgo.com/?q=" + Uri.encode(t)
    }
}

fun hostOf(url: String) = if (url.isEmpty()) "" else Uri.parse(url).host?.removePrefix("www.") ?: url

class TabState(ctx: Context, start: String?) {
    var title by mutableStateOf("Новая вкладка")
    var url by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    val web = WebView(ctx)

    init {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) { url = u }
            override fun doUpdateVisitedHistory(v: WebView, u: String, r: Boolean) {
                url = u; canBack = v.canGoBack(); canForward = v.canGoForward()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { progress = p }
            override fun onReceivedTitle(v: WebView, t: String) { title = t }
        }
        if (start != null) load(start)
    }

    fun load(input: String) {
        val u = normalize(input)
        if (u.isNotEmpty()) { url = u; web.loadUrl(u) }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val start = intent?.data?.toString()
        setContent { App(start) }
    }
}

@Composable
fun App(start: String?) {
    val ctx = LocalContext.current
    val tabs = remember { mutableStateListOf(TabState(ctx, start)) }
    var cur by remember { mutableIntStateOf(0) }
    var switcher by remember { mutableStateOf(false) }
    val tab = tabs[cur.coerceIn(0, tabs.lastIndex)]

    BackHandler(enabled = switcher || tab.canBack) {
        if (switcher) switcher = false else tab.web.goBack()
    }

    Box(Modifier.fillMaxSize().background(Color(0xFFF2F2F7))) {
        key(tab) {
            if (tab.url.isEmpty()) StartPage(tab)
            else AndroidView({ tab.web }, Modifier.fillMaxSize().statusBarsPadding())
        }

        Column(
            Modifier.align(Alignment.BottomCenter).imePadding().navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            GlassBar(tab, tabs.size, onTabs = { switcher = true })
        }

        AnimatedVisibility(
            switcher,
            enter = fadeIn() + scaleIn(initialScale = .92f),
            exit = fadeOut() + scaleOut(targetScale = .92f)
        ) {
            Switcher(
                tabs, cur,
                onPick = { cur = it; switcher = false },
                onClose = { i ->
                    if (tabs.size == 1) tabs[0] = TabState(ctx, null)
                    else { tabs.removeAt(i); cur = cur.coerceAtMost(tabs.lastIndex) }
                },
                onNew = { tabs.add(TabState(ctx, null)); cur = tabs.lastIndex; switcher = false },
                onDone = { switcher = false }
            )
        }
    }
}

@Composable
fun GlassBar(tab: TabState, tabCount: Int, onTabs: () -> Unit) {
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    var input by remember(tab) { mutableStateOf("") }
    var focused by remember(tab) { mutableStateOf(false) }
    val pill = RoundedCornerShape(26.dp)

    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(horizontal = 8.dp, vertical = 6.dp)) {
        Row(
            Modifier.fillMaxWidth().height(46.dp).clip(pill).background(Color.Black.copy(.06f)).padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f)) {
                val shown = if (focused) input else hostOf(tab.url)
                if (shown.isEmpty()) Text("Поиск или адрес", color = Ink.copy(.4f), fontSize = 16.sp,
                    modifier = Modifier.align(Alignment.Center))
                BasicTextField(
                    value = shown,
                    onValueChange = { input = it },
                    singleLine = true,
                    cursorBrush = SolidColor(Color(0xFF007AFF)),
                    textStyle = TextStyle(color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                        textAlign = if (focused) TextAlign.Start else TextAlign.Center),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                    keyboardActions = KeyboardActions(onGo = { tab.load(input); focus.clearFocus() }),
                    modifier = Modifier.fillMaxWidth().onFocusChanged {
                        if (it.isFocused && !focused) input = tab.url
                        focused = it.isFocused
                    }
                )
            }
            if (tab.url.isNotEmpty()) {
                Icon(
                    if (tab.progress in 1..99) Icons.Default.Close else Icons.Default.Refresh, null,
                    tint = Ink.copy(.7f),
                    modifier = Modifier.size(20.dp).clickable {
                        if (tab.progress in 1..99) tab.web.stopLoading() else tab.web.reload()
                    }
                )
            }
        }
        if (tab.progress in 1..99) {
            Box(Modifier.padding(horizontal = 18.dp, vertical = 3.dp).fillMaxWidth(tab.progress / 100f).height(2.dp)
                .clip(CircleShape).background(Color(0xFF007AFF)))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { tab.web.goBack() }, enabled = tab.canBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = if (tab.canBack) Ink else Ink.copy(.2f))
            }
            IconButton(onClick = { tab.web.goForward() }, enabled = tab.canForward) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = if (tab.canForward) Ink else Ink.copy(.2f))
            }
            IconButton(onClick = {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, tab.url) }
                ctx.startActivity(Intent.createChooser(i, null))
            }, enabled = tab.url.isNotEmpty()) {
                Icon(Icons.Default.Share, null, tint = if (tab.url.isNotEmpty()) Ink else Ink.copy(.2f))
            }
            IconButton(onClick = onTabs) {
                Box(Modifier.size(22.dp).border(1.6.dp, Ink, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                    Text(tabCount.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Ink)
                }
            }
        }
    }
}

@Composable
private fun IconBtn(enabled: Boolean, onClick: () -> Unit) { /* заглушка для будущих кнопок */ }

@Composable
fun StartPage(tab: TabState) {
    val sites = listOf(
        "Google" to "google.com", "YouTube" to "youtube.com", "Wikipedia" to "wikipedia.org",
        "GitHub" to "github.com", "Reddit" to "reddit.com", "Яндекс" to "ya.ru",
        "Telegram" to "web.telegram.org", "Maps" to "maps.google.com"
    )
    val colors = listOf(0xFF4285F4, 0xFFFF0033, 0xFF636466, 0xFF24292E, 0xFFFF4500, 0xFFFC3F1D, 0xFF2AABEE, 0xFF34A853)
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("Избранное", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(20.dp))
        LazyVerticalGrid(GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            items(sites.size) { i ->
                Column(Modifier.clickable { tab.load(sites[i].second) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(60.dp).clip(RoundedCornerShape(16.dp)).background(Color(colors[i])),
                        contentAlignment = Alignment.Center) {
                        Text(sites[i].first.take(1), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(sites[i].first, fontSize = 12.sp, color = Ink, maxLines = 1)
                }
            }
        }
    }
}

@Composable
fun Switcher(tabs: List<TabState>, cur: Int, onPick: (Int) -> Unit, onClose: (Int) -> Unit, onNew: () -> Unit, onDone: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xF2E5E5EA))) {
        LazyVerticalGrid(
            GridCells.Fixed(2),
            Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(tabs.size) { i ->
                val t = tabs[i]
                Column(
                    Modifier.height(190.dp).glass(RoundedCornerShape(22.dp))
                        .then(if (i == cur) Modifier.border(2.dp, Color(0xFF007AFF), RoundedCornerShape(22.dp)) else Modifier)
                        .clickable { onPick(i) }.padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(t.title, Modifier.weight(1f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Icon(Icons.Default.Close, null, tint = Ink, modifier = Modifier.size(18.dp).clickable { onClose(i) })
                    }
                    Spacer(Modifier.weight(1f))
                    Text(hostOf(t.url).ifEmpty { "Избранное" }, fontSize = 12.sp, color = Ink.copy(.55f))
                }
            }
        }
        Row(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp).fillMaxWidth()
                .glass(RoundedCornerShape(30.dp)).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNew) { Icon(Icons.Default.Add, null, tint = Ink) }
            Text("Готово", color = Color(0xFF007AFF), fontWeight = FontWeight.SemiBold, fontSize = 17.sp,
                modifier = Modifier.clickable { onDone() }.padding(horizontal = 16.dp, vertical = 10.dp))
        }
    }
}
